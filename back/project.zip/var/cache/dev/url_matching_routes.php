<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'default', '_controller' => 'App\\Controller\\DefaultController::index'], null, null, null, false, false, null]],
        '/oauth' => [[['_route' => 'oauth', '_controller' => 'App\\Controller\\DefaultController::oauth'], null, null, null, false, false, null]],
        '/pseudo' => [[['_route' => 'pseudo', '_controller' => 'App\\Controller\\DefaultController::pseudo'], null, null, null, false, false, null]],
        '/exchange_token' => [[['_route' => 'exchange_token', '_controller' => 'App\\Controller\\DefaultController::token'], null, null, null, false, false, null]],
        '/spotifyRequest' => [[['_route' => 'spotifyRequest', '_controller' => 'App\\Controller\\DefaultController::spotifyRequest'], null, null, null, false, false, null]],
        '/update' => [[['_route' => 'update', '_controller' => 'App\\Controller\\DefaultController::update'], null, null, null, false, false, null]],
        '/createPlaylist' => [[['_route' => 'createPlaylist', '_controller' => 'App\\Controller\\DefaultController::createPlaylist'], null, null, null, false, false, null]],
        '/error' => [[['_route' => 'error', '_controller' => 'App\\Controller\\DefaultController::error'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
