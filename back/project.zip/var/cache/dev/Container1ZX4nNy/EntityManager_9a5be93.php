<?php

namespace Container1ZX4nNy;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHoldere1cff = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializere96a7 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesf0fd8 = [
        
    ];

    public function getConnection()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getConnection', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getMetadataFactory', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getExpressionBuilder', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'beginTransaction', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->beginTransaction();
    }

    public function getCache()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getCache', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getCache();
    }

    public function transactional($func)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'transactional', array('func' => $func), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'wrapInTransaction', array('func' => $func), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'commit', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->commit();
    }

    public function rollback()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'rollback', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getClassMetadata', array('className' => $className), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'createQuery', array('dql' => $dql), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'createNamedQuery', array('name' => $name), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'createQueryBuilder', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'flush', array('entity' => $entity), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'clear', array('entityName' => $entityName), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->clear($entityName);
    }

    public function close()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'close', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->close();
    }

    public function persist($entity)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'persist', array('entity' => $entity), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'remove', array('entity' => $entity), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'refresh', array('entity' => $entity), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'detach', array('entity' => $entity), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'merge', array('entity' => $entity), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getRepository', array('entityName' => $entityName), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'contains', array('entity' => $entity), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getEventManager', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getConfiguration', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'isOpen', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getUnitOfWork', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getProxyFactory', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'initializeObject', array('obj' => $obj), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'getFilters', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'isFiltersStateClean', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'hasFilters', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return $this->valueHoldere1cff->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializere96a7 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHoldere1cff) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHoldere1cff = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHoldere1cff->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, '__get', ['name' => $name], $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        if (isset(self::$publicPropertiesf0fd8[$name])) {
            return $this->valueHoldere1cff->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere1cff;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldere1cff;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, '__set', array('name' => $name, 'value' => $value), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere1cff;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldere1cff;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, '__isset', array('name' => $name), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere1cff;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHoldere1cff;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, '__unset', array('name' => $name), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere1cff;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHoldere1cff;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, '__clone', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        $this->valueHoldere1cff = clone $this->valueHoldere1cff;
    }

    public function __sleep()
    {
        $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, '__sleep', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;

        return array('valueHoldere1cff');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializere96a7 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializere96a7;
    }

    public function initializeProxy() : bool
    {
        return $this->initializere96a7 && ($this->initializere96a7->__invoke($valueHoldere1cff, $this, 'initializeProxy', array(), $this->initializere96a7) || 1) && $this->valueHoldere1cff = $valueHoldere1cff;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHoldere1cff;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHoldere1cff;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
